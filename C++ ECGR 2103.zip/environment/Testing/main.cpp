#include <iostream>
#include <cstring>
#include <string.h>
#include <cmath>

using namespace std;

int main(){
}