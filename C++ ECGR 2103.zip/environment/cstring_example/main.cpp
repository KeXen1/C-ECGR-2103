#include <iostream>

using namespace std;

int main(){
    
    int testArray[] = {1, 2, 3};
    char cstring[] = {'H', 'e', 'l', 'l', 'o', '\0'};
    
    string str = "Hello!";
    
    cout << testArray << endl;
    cout << cstring << endl;
    
    /*git clone <<Link to github repository>> -- links to repository
    git add -- Adds a file (and new updates) into respoitory
    git status -- shows status/file of repository
    git commit -m "Adding files" -- short description of what you did
    git push -> Enter Username and Password -- this puts your code into github
    git pull -- puts update
    using git helps you stand out in resume!
    */
    
    return 0;
}
    