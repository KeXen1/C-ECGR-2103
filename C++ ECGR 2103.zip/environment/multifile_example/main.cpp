#include <iostream>
#include "lib/my_math.h"

using namespace std;

int main(){
    int a = 10;
    int b = 2;
    
    cout << pow(a,b) << endl;
    printError();
    
    return 0;
}